"""
data_pipelines/textbook/test_scripts/try_grammar_rule.py

TRIAL: grammar detection rules for ONE grammar point, written by AI from
real grammar references, tested against examples labeled by people, then
used to pull sentences from Tatoeba.

WHAT DEFINES A POINT (the "context" every AI call gets)
  - the official HSK grammar list entry (label + any examples it has)
  - the AllSet Learning Chinese Grammar Wiki ("ASG") pages listed for the
    point in test_scripts/grammar_sources.json: "is" pages (this point:
    structure, explanation, examples) and "not" pages (other uses of the
    same words: structure + examples). Parsed by parse_asg.py into
    data/intermediate/allsetlearning/asg_points.json.
  ASG is CC BY-NC-SA 3.0: non-commercial use only, with attribution.

STEPS (run in order)
  sources   AI (Sonnet, one call) sorts the ASG pages that use the point's
            words into is / not / unsure and saves them to
            grammar_sources.json, marked "_proposed" -- check them.
  context   (optional) prints the definition every AI call will get.
  write     AI (Sonnet) writes the rule as a section of grammar_rules.md. It
            sees the context, the labeled examples ("is" pages = must match,
            "not" pages = must not match) as the course's tagger splits and
            tags them, and some unlabeled course sentences.
  validate  A. LABELED TEST (no AI): the rule on every labeled example --
               how many examples of the point it matches, and which
               counter-examples it wrongly matches.
            B. (only with --check) COURSE SENTENCES: the rule on every
               pipeline sentence with the words, compared with an AI check. Checks are cached in
               output/check_cache.json, so re-running costs nothing.
            --revise: sends A's failures (labels written by people: right)
            and B's disagreements (an AI's opinion: may be wrong) back to the
            writer once, keeps the old file as grammar_rules.md.bak, and
            re-runs A and B.
  tatoeba   Your filtered Tatoeba file through every gate:
              1. has an English translation   2. contains the word(s)
              3. new (not in the DB, not a duplicate once in Simplified)
              4. at most MAX_UNKNOWN_CHARS characters no word of the level uses
              5. tagged, and really at this HSK level
              6. the RULE finds the point
              7. TWO independent checks both say yes; the first picks an
                 accurate English among Tatoeba's (none -> dropped)
              8. the difficulty review passes it
            Steps 7-8 cost money, so they run on the shortest sentences
            first, CHECK_BATCH at a time, and stop once the point has
            --target sentences at the level (its course sentences count).

Tagging results (for labeled examples and Tatoeba sentences) are cached in
output/tag_cache.json; --retag tags again. THE REAL DATABASE IS NEVER
TOUCHED: everything runs on output/scratch_textbook.db and is rolled back.

USAGE (from the repo root)
    python data_pipelines/textbook/test_scripts/parse_asg.py          # once
    python data_pipelines/textbook/test_scripts/try_grammar_rule.py sources --code 1-42
    python data_pipelines/textbook/test_scripts/try_grammar_rule.py write --code 1-10 --redo
    python data_pipelines/textbook/test_scripts/try_grammar_rule.py validate --code 1-10
    python data_pipelines/textbook/test_scripts/try_grammar_rule.py validate --code 1-10 --revise
    python data_pipelines/textbook/test_scripts/try_grammar_rule.py tatoeba --code 1-10
"""
import argparse
import atexit
import os
import csv
import hashlib
import json
import random
import re
import shutil
import sys
import threading
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]          # .../learning-mandarin
TEST_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(TEST_DIR))

import grammar_rules as gr  # noqa: E402

DATA_DIR = TEST_DIR.parent / "data"
OUT_DIR = TEST_DIR / "output"
SCRATCH_DB = OUT_DIR / f"scratch_textbook_{os.getpid()}.db"   # one per run, so two runs can't collide
RULES_PATH = TEST_DIR / "grammar_rules.md"
SOURCES_PATH = TEST_DIR / "grammar_sources.json"
HIDDEN_PATH = TEST_DIR / "hidden_words.json"
MANUAL_PATH = TEST_DIR / "manual_points.json"
EXAMPLE_LEVELS_PATH = TEST_DIR / "grammar_level_by_examples.json"   # written by run_all_grammar.py
LEVELS_PATH = TEST_DIR / "grammar_level_overrides.json"   # 2025-syllabus levels (match_grammar_levels.py)     # hand-written words/pages for points the AI can't match
BATCH_STATE_PATH = TEST_DIR / "output" / "batch" / "state.json"
ASG_PATH = DATA_DIR / "intermediate" / "allsetlearning" / "asg_points.json"
CACHE_PATH = OUT_DIR / "check_cache.json"
TAG_CACHE_PATH = OUT_DIR / "tag_cache.json"
DEFAULT_TSV = DATA_DIR / "intermediate" / "tatoeba" / "cmn_filtered.tsv"

WRITER_MODEL = "claude-sonnet-5-5"
CHECK_MODEL = "claude-haiku-4-5"
# Judges the labeled test itself (does a counter-example contain the point? does a guard's flag go
# beyond the easier point?) -- few sentences, and they decide which rules are trusted, so the
# stronger model. Haiku got 只好不买了 ("had to not buy") wrong for 不 negation.
JUDGE_MODEL = "claude-sonnet-5-5"
WORKERS = 8
CHECK_BATCH = 20              # sentences per check call
DEFAULT_TARGET = 20           # tatoeba: good sentences wanted per point at the level
MAX_UNKNOWN_CHARS = 2
SAMPLES_PER_STEP = 12
WRITER_EXAMPLES = 40          # labeled examples (each side) shown to the writer
WRITER_UNLABELED = 25         # unlabeled course sentences shown to the writer
TAG_CACHE_VERSION = 1
_CJK_RE = re.compile(r"[㐀-鿿]")


# --------------------------------- SETUP ---------------------------------

def point_db_at_scratch_copy():
    """Copies the real textbook.db and makes the app use the copy. Runs
    before anything imports app.textbook.db_utils (it opens the DB at import)."""
    import app.core.config.data as data_cfg
    real = Path(data_cfg.TEXTBOOK_DB)
    if not real.exists():
        raise SystemExit(f"No database at {real} -- run main.py first.")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for old in OUT_DIR.glob("scratch_textbook*.db"):          # left over from runs that crashed
        if old != SCRATCH_DB and time.time() - old.stat().st_mtime > 6 * 3600:
            old.unlink(missing_ok=True)
    shutil.copy(real, SCRATCH_DB)
    atexit.register(lambda: SCRATCH_DB.unlink(missing_ok=True))
    data_cfg.TEXTBOOK_DB = SCRATCH_DB if isinstance(data_cfg.TEXTBOOK_DB, Path) else str(SCRATCH_DB)
    from app.textbook import db_utils
    if Path(db_utils.engine.url.database).resolve() != SCRATCH_DB.resolve():
        raise SystemExit(f"Safety stop: the app opened {db_utils.engine.url.database}, not the scratch copy.")
    return real


class OutOfCredits(BaseException):
    """The Anthropic account ran out of credit. A BaseException, so no
    `except Exception` on the way swallows it: the run stops cleanly and
    nothing half-done is saved as done."""


def install_credit_guard():
    """Every Anthropic call in this process (ours, the tagger's, the
    review's) raises OutOfCredits when the balance is too low."""
    try:
        import anthropic
        Messages = type(anthropic.Anthropic(api_key="unused").messages)   # the class every client uses
    except Exception as e:
        print(f"[warning] couldn't install the out-of-credit guard ({e!r}): if the credit runs out, "
              "watch for many 'AI call failed' notes")
        return
    if getattr(Messages.create, "_credit_guard", False):
        return
    original = Messages.create

    def guarded(self, *a, **kw):
        try:
            return original(self, *a, **kw)
        except anthropic.APIStatusError as e:
            text = str(e).lower()
            if "credit balance" in text or "billing" in text or getattr(e, "status_code", 0) == 402:
                raise OutOfCredits(str(e)) from None
            raise
    guarded._credit_guard = True
    Messages.create = guarded


# The tagger asks Haiku to re-split sentences with unusual words. Here that
# is switched off (HanLP's split + the pipeline's own word-splitting rules
# instead): it was most of the cost of tagging thousands of sentences, and
# barely changes the result. RESEGMENT = True turns it back on.
RESEGMENT = False


def apply_level_overrides():
    """Moves grammar points to their 2025-syllabus level (grammar_level_overrides.json)
    in the SCRATCH database only, committed so every later step sees it."""
    from app.textbook.db_utils import engine, get_session
    from app.textbook.models import GrammarTip
    if Path(engine.url.database).resolve() != SCRATCH_DB.resolve():
        raise SystemExit("Safety stop: level overrides are only applied to the scratch copy.")
    for path, what in ((LEVELS_PATH, "2025-syllabus levels"),
                       (EXAMPLE_LEVELS_PATH, "Levels from the points' own examples")):
        moves = {c: v for c, v in load_json(path, {}).items() if not c.startswith("_") and isinstance(v, dict)}
        if not moves:
            continue
        with get_session() as db:
            for tip in db.query(GrammarTip).filter(GrammarTip.grammar_code.in_(list(moves))).all():
                tip.hsk_level = int(moves[tip.grammar_code]["level"])
        print(f"{what} applied to {len(moves)} grammar point(s) ({path.name})")


def get_client():
    import anthropic
    from app.core.config.shared import settings
    if not settings.CLAUDE_API_KEY:
        raise SystemExit("CLAUDE_API_KEY is not set.")
    return anthropic.Anthropic(api_key=settings.CLAUDE_API_KEY, max_retries=6)


def create(client, model: str, prompt: str, max_tokens: int):
    """One API call. If the model used up max_tokens before writing any
    text (it can spend them thinking first -- the empty 1-40 answers), ask
    again with 4x the room, up to 32000 tokens."""
    while True:
        response = client.messages.create(model=model, max_tokens=max_tokens,
                                          messages=[{"role": "user", "content": prompt}])
        text = "".join(b.text for b in response.content if hasattr(b, "text"))
        if text.strip() or getattr(response, "stop_reason", "") != "max_tokens" or max_tokens >= 32000:
            return response, text
        max_tokens = min(32000, max_tokens * 4)


def call(client, model: str, prompt: str, max_tokens: int) -> str:
    return create(client, model, prompt, max_tokens)[1]


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def save_json(path: Path, data, merge=True):
    """Writes a cache file. merge: keep entries another run saved meanwhile."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if merge:
        on_disk = load_json(path, {})
        if on_disk.get("_v", data.get("_v")) == data.get("_v"):
            data = {**on_disk, **data}
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=0), encoding="utf-8")
    os.replace(tmp, path)


def _cjk_strings(x) -> list[str]:
    """Every string with Chinese in it, anywhere inside x."""
    if isinstance(x, str):
        return [x.strip()] if _CJK_RE.search(x) else []
    if isinstance(x, dict):
        return [s for v in x.values() for s in _cjk_strings(v)]
    if isinstance(x, list):
        return [s for v in x for s in _cjk_strings(v)]
    return []


# --------------------------------- THE POINT ---------------------------------

class Point:
    """The grammar point: list entry, marker words, ASG pages, labeled examples."""
    def __init__(self, db, code: str, contains, need_sources=True):
        from app.textbook.models import GrammarTip
        from data_pipelines.textbook.scripts import detect_grammar as dg
        tip = db.query(GrammarTip).filter(GrammarTip.grammar_code == code).first()
        if tip is None:
            raise SystemExit(f"No grammar point {code} in the DB.")
        self.code, self.level, self.label = code, tip.hsk_level, tip.raw_text
        content = load_json_str(tip.content_json)
        self.list_examples = list(dict.fromkeys(
            s for k, v in content.items() if "example" in k.lower() for s in _cjk_strings(v)))
        manual = {k: v for k, v in load_json(MANUAL_PATH, {}).get(code, {}).items()}
        saved = load_json(SOURCES_PATH, {}).get(code, {}).get("_words")
        words = contains or manual.get("words") or saved or dg.GRAMMAR_MARKERS.get(code) or EXTRA_MARKERS.get(code)
        if not words:                       # the label's own words, if they are real words
            from app.textbook.models import Vocab as _V
            vocab = {h for (h,) in db.query(_V.hanzi).all()}
            words = real_label_words(self.label, vocab, {ch for h in vocab for ch in h})
        self.markers = sorted(set(words), key=len, reverse=True)
        if not self.markers:
            raise SystemExit(f"No marker words known for {code}: pass --contains <words>.")
        # The first HSK level where the point can be taught: its list level, or
        # later if none of its words is in the vocab list that early (比 is an
        # HSK 2 word, so 1-18 can't be drilled before HSK 2). The marker words
        # are alternatives -- any one shows the point -- so the EARLIEST word
        # counts: 都 is HSK 1, so 1-10 starts at HSK 1 though 一起 is HSK 2.
        from app.textbook.models import Vocab
        self.word_levels = {h: lv for h, lv in db.query(Vocab.hanzi, Vocab.hsk_level)
                            .filter(Vocab.hanzi.in_(self.markers)).all()}
        known = [lv for lv in self.word_levels.values() if lv is not None]
        self.first_level = max(self.level, min(known)) if known else self.level
        self.list_others = []
        for p in db.query(GrammarTip).order_by(GrammarTip.id).all():
            if p.grammar_code == code:
                continue
            c = load_json_str(p.content_json)
            hay = (p.raw_text or "") + " " + " ".join(str(c.get(k) or "") for k in ("label", "label_full", "sub", "pattern"))
            if any(m in hay for m in self.markers):
                self.list_others.append((p.grammar_code, p.hsk_level, p.raw_text))

        asg = {p["id"]: p for p in load_json(ASG_PATH, {}).get("points", [])}
        if not asg:
            raise SystemExit(f"{ASG_PATH} is missing: run parse_asg.py first.")
        self.asg = asg
        sources = load_json(SOURCES_PATH, {}).get(code)
        if manual.get("is") or manual.get("not"):   # hand-matched pages are added to the AI's
            sources = {k: dict((sources or {}).get(k, {})) for k in ("is", "not", "unsure")}
            for g in ("is", "not"):
                for pid, title in manual.get(g, {}).items():
                    for other in ("is", "not", "unsure"):
                        sources[other].pop(pid, None)
                    sources[g][pid] = title
        if not sources:
            if need_sources:
                raise SystemExit(f"No entry for {code} in {SOURCES_PATH}: run  sources --code {code}  first.")
            sources = {}
        missing = [i for kind in ("is", "not", "unsure") for i in sources.get(kind, {}) if i not in asg]
        if missing:
            raise SystemExit(f"grammar_sources.json names page(s) not in asg_points.json: {missing}")
        self.is_pages = [asg[i] for i in sources.get("is", {})]
        self.not_pages = [asg[i] for i in sources.get("not", {})]
        self.unsure = list(sources.get("unsure", {}))

        pos = {e["hanzi"]: f"{p['id']} {p['title']}" for p in self.is_pages for e in p["examples"]}
        for s in self.list_examples:
            if len(s) <= 40:
                pos.setdefault(s, "HSK list example")
        # a counter-example must use the word AS the page's grammar point: the
        # word is in what the page marks (<em>), its structure or its keyword.
        # Otherwise it only happens to contain it (a 的时候 page example with
        # 在 in it may well be progressive 在).
        def teaches_marker(p, e):
            taught = [m.get("text", "") for m in e.get("marked", [])] + p.get("structures", []) + [p.get("keyword", "")]
            return any(m in e["hanzi"] and any(m in t for t in taught) for m in self.markers)
        neg = {e["hanzi"]: f"{p['id']} {p['title']}" for p in self.not_pages for e in p["examples"]
               if teaches_marker(p, e)}
        self.conflicts = sorted(set(pos) & set(neg))
        # a "not" page none of whose examples teach the word is left out of
        # what the AI is told (it was filed there by mistake, or has no examples)
        teaching = {src.split(" ", 1)[0] for src in neg.values()}
        self.idle_not = [p["id"] for p in self.not_pages if p["id"] not in teaching]
        self.not_pages = [p for p in self.not_pages if p["id"] in teaching]
        self.positives = {h: src for h, src in pos.items() if h not in neg}
        self.negatives = {h: src for h, src in neg.items() if h not in pos}

    def short_def(self) -> str:
        """A few lines: label, structures and examples of its "is" pages."""
        out = [f"{self.code} (HSK {self.level}): {self.label}"]
        for p in self.is_pages[:3]:
            st = " | ".join(dict.fromkeys(p["structures"][:3]))
            ex = "; ".join(e["hanzi"] for e in p["examples"][:3])
            out.append(f"  - {p['title']}: {st}" + (f"  e.g. {ex}" if ex else ""))
        return "\n".join(out)

    def context(self, full=True) -> str:
        """The definition every AI call gets. full=False: shorter, for the
        per-sentence checks."""
        n_ex, n_text = (8, 1500) if full else (5, 600)
        out = [f"GRAMMAR POINT {self.code} (HSK {self.level}). Official HSK grammar list: {self.label}"]
        if self.list_examples:
            out.append("  Official examples: " + " / ".join(self.list_examples[:6]))
        out.append("\nWHAT IT IS (from the AllSet Learning Chinese Grammar Wiki):")
        for p in self.is_pages:
            out.append(f"\n### {p['title']}")
            if p["structures"]:
                out.append("Structure: " + "  |  ".join(dict.fromkeys(p["structures"])))
            text = "\n".join(l for l in p["text"].splitlines() if not l.startswith("## "))
            if text:
                out.append(text[:n_text] + ("..." if len(text) > n_text else ""))
            if p["examples"]:
                out.append("Examples:")
                out += [f"  {e['hanzi']}  ({e['english']})" for e in p["examples"][:n_ex]]
        out.append("\nNOT THIS POINT -- other grammar that uses the same words (a sentence that only shows "
                   "one of these must not count):")
        for p in self.not_pages:
            ex = "; ".join(f"{e['hanzi']} ({e['english']})" for e in p["examples"][:2])
            st = " | ".join(dict.fromkeys(p["structures"][:3]))
            out.append(f"- {p['title']}: {st}" + (f"  e.g. {ex}" if ex else ""))
        for c, lv, label in self.list_others:
            out.append(f"- HSK list {c} (HSK {lv}): {label}")
        return "\n".join(out)

    def show(self):
        print(f"Point {self.code} (HSK {self.level}): {self.label}")
        print(f"Words: {' '.join(f'{m} (HSK {self.word_levels.get(m) or "-"})' for m in self.markers)}")
        if self.first_level != self.level:
            print(f"  -> none of its words is HSK {self.level}, so it can first be taught at HSK {self.first_level}")
        print(f"Official list examples found: {len(self.list_examples)}"
              + (f"  e.g. {' / '.join(self.list_examples[:3])}" if self.list_examples else ""))
        if not self.is_pages and not self.not_pages:
            print()
            return
        print("AllSet Learning pages for this point:")
        for p in self.is_pages:
            print(f"  {p['id']}  {p['title']}  ({len(p['examples'])} examples)")
        print(f"Pages for other uses (counter-examples): {len(self.not_pages)}; left out as unsure: {len(self.unsure)}"
              + (f"; 'not' pages with no example teaching the word, ignored: {len(self.idle_not)}" if self.idle_not else ""))
        print(f"Labeled test sentences: {len(self.positives)} examples, {len(self.negatives)} counter-examples"
              + (f" ({len(self.conflicts)} on both sides, dropped)" if self.conflicts else ""))
        print()


# words in grammar-point labels that describe the point rather than being part of it
_LABEL_STOP = set("用 表示 强调 句 结构 格式 句型 副词 介词 连词 助词 动词 形容词 名词 量词 代词 数词 语气 程度 范围 "
                  "时间 频率 关联 否定 疑问 比较 复句 动态 结果 趋向 补语 表达 协同 进行态 某 等 的".split())


def label_words(label: str) -> list[str]:
    """The Chinese words of a point's label, e.g. 3-41 一……也/都+不/没 ->
    一 也 都 不 没; for 'category：words' labels only the words part."""
    part = label.split("：", 1)[1] if "：" in label else label
    for stop in sorted(_LABEL_STOP, key=len, reverse=True):
        if len(stop) > 1:
            part = part.replace(stop, " ")
    return [w for w in re.findall(r"[\u3400-\u9fff]+", part) if w not in _LABEL_STOP]


# grammar terms: a label word containing one describes the point (谓语句,
# 趋向补语), it isn't a word of the point (越来越, 什么的)
_TERMS = ("句", "词", "语", "态", "补", "宾", "谓", "结构", "类型", "重叠", "短语")

# points whose label has no word of its own but whose sentences always
# contain one (the comparison points 2-58 比……多了 and 2-59 跟……一样)
EXTRA_MARKERS = {"2-58": ["比"], "2-59": ["一样"]}


def real_label_words(label: str, vocab: set, chars: set) -> list[str]:
    """label_words() that are real words: on the vocab list, or 1-4
    characters from list words with no grammar term in them."""
    return [w for w in label_words(label)
            if w in vocab or (len(w) <= 4 and all(ch in chars for ch in w) and not any(t in w for t in _TERMS))]


def load_json_str(s):
    try:
        return json.loads(s or "{}")
    except json.JSONDecodeError:
        return {}


def clauses_of(sentence):
    from data_pipelines.textbook.scripts import detect_grammar as dg
    return dg.clauses(dg.Context(sentence.hanzi, dg.sentence_words(sentence), None))


def pipeline_sentences(db, point: Point):
    from sqlalchemy import or_
    from app.textbook.models import Sentence
    return (db.query(Sentence).filter(or_(*[Sentence.hanzi.contains(m) for m in point.markers]))
            .order_by(Sentence.id).all())


# --------------------------------- TAGGING (cached) ---------------------------------

class Tagger:
    """Tags any sentence exactly like the pipeline does, inside a savepoint
    that is rolled back. Results cached in output/tag_cache.json."""
    def __init__(self, db, retag=False):
        self.db, self.ready = db, False
        self.cache = {} if retag else load_json(TAG_CACHE_PATH, {})
        if self.cache.get("_v") != TAG_CACHE_VERSION:
            self.cache = {"_v": TAG_CACHE_VERSION}
        self.aliases = erhua_aliases(db)
        # sentences tagged before the aliases existed are tagged again (no AI, just HanLP)
        stale = [h for h, r in self.cache.items() if h != "_v" and isinstance(r, dict)
                 and not r.get("erhua") and any(a in h for a in self.aliases)]
        for h in stale:
            self.cache.pop(h, None)
        self.n = 0

    def _setup(self):
        from app.textbook.db_utils import get_vocab_hanzi_through_level
        from app.textbook.models import GrammarTip
        from data_pipelines.textbook.scripts import hsk_vocab_source as hvs
        from data_pipelines.textbook.scripts import tag_sentences as ts
        from data_pipelines.textbook.scripts import detect_grammar as dg
        self.ts, self.dg = ts, dg
        if not RESEGMENT:
            ts.haiku_resegment_sentence = lambda hanzi, logger: ts.segment_sentence(hanzi)
        if self.aliases and not getattr(ts.segment_sentence, "_erhua", False):
            plain, aliases = ts.segment_sentence, self.aliases

            def segment_with_erhua(hanzi):
                """HanLP's 有点 is the list's 有点儿: same word, written without 儿."""
                words = plain(hanzi)
                out = []
                for i, (w, p) in enumerate(words):
                    nxt = words[i + 1][0] if i + 1 < len(words) else ""
                    if (w in aliases and p not in ("NT", "NUM")
                            and not (w == "一点" and nxt[:1] in "半钟刻零多一二三四五六七八九十")):
                        w = aliases[w]
                    out.append((w, p))
                return out
            segment_with_erhua._erhua = True
            ts.segment_sentence = segment_with_erhua
            print(f"  Written without 儿, counted as the list word: "
                  f"{' '.join(f'{k}={v}' for k, v in sorted(aliases.items()))}", flush=True)
        logger, _ = ts.setup_logging()
        self.run = ts.Run(logger, hvs.load_entries(str(ts.VOCAB_PATH)),
                          get_vocab_hanzi_through_level(self.db, hvs.MAX_LEVEL),
                          ts.load_segmentation_cache(), estimate=True)
        points = self.db.query(GrammarTip).all()
        self.detectors, _ = dg.build_detectors(points)
        self.level_of_point = {p.grammar_code: p.hsk_level for p in points}
        self.ready = True

    def _result(self, s, bump):
        from app.textbook.models import WordType
        from data_pipelines.textbook.scripts import review_sentences as rs
        rows = sorted(s.vocab_links, key=lambda r: r.position)
        return {"clauses": clauses_of(s), "words": rs.sentence_words(s), "level": s.hsk_level,
                "vocab": [[r.vocab.hanzi, r.vocab.hsk_level, r.vocab.word_type == WordType.proper_noun] for r in rows],
                "bump": list(bump[2]) if bump else []}

    def tag(self, hanzi: str) -> dict:
        if hanzi in self.cache:
            return self.cache[hanzi]
        if not self.ready:
            self._setup()
        from app.textbook.db_utils import upsert_import_sentence
        from app.textbook.models import SentenceSource
        self.n += 1
        sp = self.db.begin_nested()
        try:
            ext = "trial-" + hashlib.md5(hanzi.encode()).hexdigest()[:12]
            s, written = upsert_import_sentence(self.db, hanzi=hanzi, english="", external_id=ext,
                                                source=SentenceSource.external)
            if written:
                self.ts.tag_sentence(self.db, self.run, s)
                self.db.expire(s, ["vocab_links"])
                _, bump = self.dg.detect_sentence(self.db, s, self.detectors, self.level_of_point)
            else:
                bump = None                      # already a pipeline sentence: its stored tags
            res = self._result(s, bump)
            res["erhua"] = True
            self.cache[hanzi] = res
        except Exception as e:
            res = {"error": f"{e!r}"[:200]}
        finally:
            sp.rollback()
        return res

    def tag_all(self, texts, label: str) -> dict:
        texts = list(dict.fromkeys(texts))
        todo = sum(t not in self.cache for t in texts)
        if todo:
            print(f"Tagging {todo} {label} (cached after this run)...", flush=True)
        out = {}
        for k, t in enumerate(texts, 1):
            out[t] = self.tag(t)
            if todo and k % 100 == 0:
                print(f"  ...{k}/{len(texts)}", flush=True)
                self.save()                     # so stopping mid-way keeps what's tagged
        self.save()
        return out

    def save(self):
        save_json(TAG_CACHE_PATH, self.cache)
        if self.ready:
            self.ts.save_segmentation_cache(self.run.seg_cache)


ERHUA_NOT_SAME = {"一块儿", "早点儿"}   # 一块 = "one piece/yuan", 早点 = "breakfast": not the 儿 word


def erhua_aliases(db) -> dict:
    """{有点: 有点儿, 一点: 一点儿, 一会: 一会儿, ...}: list words ending in 儿
    whose form without 儿 (2+ characters) isn't on the list itself. Tatoeba
    mostly writes them without 儿, which tagging used to split (有 + 点) or
    leave off the list."""
    from app.textbook.models import Vocab
    listed = {h for (h,) in db.query(Vocab.hanzi).filter(Vocab.hsk_level.isnot(None)).all()}
    return {h[:-1]: h for h in listed
            if h.endswith("儿") and len(h) >= 3 and h[:-1] not in listed and h not in ERHUA_NOT_SAME}


def harder_points_with_easy_words(db, level: int) -> list[tuple]:
    """Grammar points ABOVE `level` whose words (from their labels) are all
    words a learner at `level` knows -- the ones vocabulary alone can't keep
    out, like 3-41 一……也/都+不/没 or 4-66 连⋯⋯也/都. A word counts as
    known if it is in the list at or below the level, or it is 1-2
    characters that each belong to such a word (也没 = 也 + 没). Longer
    label words that aren't on the list are descriptions (谓语句), not words.)"""
    from app.textbook.models import GrammarTip, Vocab
    known = {h for (h,) in db.query(Vocab.hanzi).filter(Vocab.hsk_level.isnot(None), Vocab.hsk_level <= level).all()}
    known_chars = {ch for h in known for ch in h}
    out = []
    for p in db.query(GrammarTip).filter(GrammarTip.hsk_level > level).order_by(GrammarTip.id).all():
        words = label_words(p.raw_text or "")
        if words and all(w in known or (len(w) <= 2 and all(ch in known_chars for ch in w)) for w in words):
            out.append((p.grammar_code, p.hsk_level, p.raw_text))
    return out


def judge_hidden_words(db, model: str, todo: dict, verdicts: dict):
    """One AI decision per hidden word (40 per call), saved to
    hidden_words.json -- after that the same word is treated the same way in
    every sentence, for free. todo: {word: (parts, gloss)}."""
    from app.textbook.models import Vocab
    parts_all = {pt for parts, _ in todo.values() for pt in parts}
    meaning = {h: e for h, e in db.query(Vocab.hanzi, Vocab.english).filter(Vocab.hanzi.in_(parts_all)).all()}
    client, words = get_client(), list(todo)
    print(f"  Deciding {len(words)} new hidden word(s) with {model} (saved to {HIDDEN_PATH.name})...", flush=True)
    for i in range(0, len(words), 40):
        chunk = words[i:i + 40]
        listing = "\n".join(
            f"  {w} = " + " + ".join(f"{pt} ({(meaning.get(pt) or '?')[:30]})" for pt in todo[w][0])
            + f"   dictionary: {todo[w][1]}" for w in chunk)
        try:
            answer = gr.extract_json(call(client, model, gr.HIDDEN_PROMPT.format(words=listing), 1500))
        except Exception as e:
            print(f"  [warning] hidden-word call failed ({e!r}); those words count as hidden this run")
            answer = {}
        for w in chunk:
            v = str(answer.get(w, "")).lower()
            if v in ("clear", "hidden"):
                verdicts[w] = {"verdict": v, "parts": " + ".join(todo[w][0]), "gloss": todo[w][1], "by": model,
                               "v": HIDDEN_VERSION}
            else:                                   # not decided: hidden this run, asked again next run
                verdicts.setdefault("_undecided_this_run", {})[w] = True
    undecided = verdicts.pop("_undecided_this_run", {})
    for w in undecided:
        verdicts[w] = {"verdict": "hidden", "parts": " + ".join(todo[w][0]), "gloss": todo[w][1], "by": "(no answer)"}
    saved = {k: v for k, v in verdicts.items() if not (isinstance(v, dict) and v.get("by") == "(no answer)")}
    HIDDEN_PATH.write_text(json.dumps({"_readme": HIDDEN_README, **{k: v for k, v in sorted(saved.items())
                                                                    if not k.startswith("_")}},
                                      ensure_ascii=False, indent=1), encoding="utf-8")
    for w in words:
        if w in verdicts:
            print(f"    {verdicts[w]['verdict']:>6}  {w} = {verdicts[w]['parts']}  ({verdicts[w]['gloss'][:40]})")


HIDDEN_VERSION = 2
HIDDEN_README = ("Dictionary words the course splits into listed parts (从没 = 从 + 没), and whether a learner "
                 "who knows the parts understands the word untaught. hidden = no: a sentence with the word is "
                 "dropped. clear = fine. Written by try_grammar_rule.py; edit freely (change hidden <-> clear, and "
                 "set \"by\": \"hand\" so a later version never asks the AI again).")


def full_dictionary(hsk_words: dict) -> dict:
    """{word: gloss}: every HSK word (all levels and versions) plus all of
    CC-CEDICT (cepy_dict), so non-HSK words like 从没 are known too."""
    out = dict(hsk_words)
    try:
        import cepy_dict
    except ImportError:
        print("[note] pip install cepy-dict  -- without it, hidden words (like 从没) are only found among HSK words")
        return out
    for entry in cepy_dict.entries():
        simplified, definitions = (entry[2] or "").strip(), entry[4]
        if simplified and simplified not in out:
            out[simplified] = "; ".join(definitions[:4]) if definitions else ""   # all its common meanings
    return out


def hidden_words(words: list[str], dictionary: dict, listed: set, skip=()) -> list[tuple]:
    """Runs of 2-3 neighbouring words that together are ONE dictionary word
    not on the course's list -- e.g. 从 + 没 = 从没 "never". Tagging splits
    such words into their listed parts, so the sentence looks easier than it
    is. Runs with one of `skip` as a part (the point's own words: 见 + 过 is
    just the point 2-32) are not reported. [(word, parts, gloss)]"""
    out = []
    for n in (3, 2):
        for i in range(len(words) - n + 1):
            w = "".join(words[i:i + n])
            if (w in dictionary and w not in listed and not any(w in o[0] for o in out)
                    and w not in skip and w + "儿" not in listed
                    and not any(part in skip for part in words[i:i + n])):
                out.append((w, words[i:i + n], str(dictionary[w])[:150]))
    return out


def blockers(res: dict, level: int) -> list[str]:
    out = []
    for h, lv, is_name in res["vocab"]:
        if lv is None and not is_name:
            out.append(f"{h} (not in list)")
        elif lv is not None and lv > level:
            out.append(f"{h} L{lv}")
    return list(dict.fromkeys(out))


def as_clauses(res: dict):
    return [[tuple(t) for t in c] for c in res["clauses"]]


# --------------------------------- CHECKS (cached) ---------------------------------

_cache_lock = threading.Lock()


def check_key(point: Point, hanzi: str, english, model: str | None = None) -> str:
    return json.dumps([gr.CHECK_VERSION, model or CHECK_MODEL, point.code, hanzi, english or []], ensure_ascii=False)


def run_checks(client, point: Point, jobs: list[dict], n: int, cache: dict, model: str | None = None) -> dict:
    """jobs: [{"hanzi", "tagged", "english"}]. Makes sure every job has n
    independent answers in the cache; returns {hanzi: [answers]}. Each pass
    sends CHECK_BATCH sentences per call (the definition once per call), in
    a different order each pass. A failed call or a missing answer counts as
    "no" this run and isn't cached."""
    failed = defaultdict(list)
    context = point.context(full=False)
    calls = 0
    model = model or CHECK_MODEL

    def one(chunk):
        items = [{"n": k + 1, "hanzi": j["hanzi"], "tagged": j["tagged"], "english": j["english"]}
                 for k, j in enumerate(chunk)]
        try:
            answers = gr.extract_json_array(call(client, model, gr.check_batch_prompt(point.code, context, items),
                                                 150 + 90 * len(items)))
            by_n = {int(a["n"]): a for a in answers if isinstance(a, dict) and "n" in a}
        except Exception as e:
            for j in chunk:
                failed[j["hanzi"]].append({"uses_point": False, "reason": f"AI call failed: {e!r}"[:200]})
            return
        for k, j in enumerate(chunk, 1):
            a = by_n.get(k)
            if not a or not isinstance(a.get("uses_point"), bool):
                failed[j["hanzi"]].append({"uses_point": False, "reason": "no answer for this sentence"})
                continue
            a = {"uses_point": a["uses_point"], "reason": str(a.get("reason", "")),
                 **({"english": a.get("english") if isinstance(a.get("english"), int)
                     and 0 <= a["english"] < len(j["english"]) else None} if j["english"] is not None else {})}
            with _cache_lock:
                cache.setdefault(check_key(point, j["hanzi"], j["english"], model), []).append(a)

    for pass_no in range(n):
        todo = [j for j in jobs if len(cache.get(check_key(point, j["hanzi"], j["english"], model), [])) <= pass_no
                and not failed[j["hanzi"]]]
        if not todo:
            continue
        random.Random(pass_no).shuffle(todo)
        chunks = [todo[i:i + CHECK_BATCH] for i in range(0, len(todo), CHECK_BATCH)]
        calls += len(chunks)
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            list(pool.map(one, chunks))
    if calls:
        print(f"  {calls} check call(s) with {model} ({CHECK_BATCH} sentences each)...", flush=True)
        save_json(CACHE_PATH, cache)
    return {j["hanzi"]: (cache.get(check_key(point, j["hanzi"], j["english"], model), []) + failed[j["hanzi"]])[:n]
            for j in jobs}


# --------------------------------- SOURCES ---------------------------------

MAX_SOURCE_PAGES = 40


def candidate_pages(point: Point) -> list[dict]:
    """ASG pages that use the point's words: keyword first, then pages whose
    examples mark one of the words, then pages whose structure has one."""
    scored = []
    for p in point.asg.values():
        marked = {m["text"] for e in p["examples"] for m in e.get("marked", [])}
        if any(m in p.get("keyword", "") for m in point.markers):
            score = 3
        elif any(m in t for t in marked for m in point.markers):
            score = 2
        elif any(m in st for st in p.get("structures", []) for m in point.markers):
            score = 1
        else:
            continue
        scored.append((score, p))
    scored.sort(key=lambda x: (-x[0], x[1]["id"]))
    return [p for _, p in scored]


def cmd_sources(db, point: Point, args):
    sources = load_json(SOURCES_PATH, {})
    if point.code in sources and not args.redo:
        raise SystemExit(f"{point.code} already has pages in {SOURCES_PATH}. Edit them, or pass --redo.")
    pages = candidate_pages(point)
    if not pages:
        raise SystemExit(f"No AllSet Learning page uses {' '.join(point.markers)}.")
    shown = pages[:MAX_SOURCE_PAGES]
    print(f"{len(pages)} page(s) use the word(s); asking about {len(shown)}.")
    listing = []
    for p in shown:
        st = " | ".join(dict.fromkeys(p["structures"][:2]))
        ex = "; ".join(e["hanzi"] for e in p["examples"][:2])
        listing.append(f"{p['id']} | {p['title']} | HSK(2021) {p.get('hsk_2021') or '?'} | structure: {st} | e.g. {ex}")
    prompt = gr.SOURCES_PROMPT.format(
        code=point.code, level=point.level, label=point.label, markers=" ".join(point.markers),
        official=("Official examples: " + " / ".join(point.list_examples[:6])) if point.list_examples else "",
        pages="\n".join(listing))
    print(f"  Asking {args.writer_model} to sort them...", flush=True)
    answer = gr.extract_json(call(get_client(), args.writer_model, prompt, 2000))
    groups = {"is": {}, "not": {}, "unsure": {}, "unrelated": {}}
    for p in shown:
        g = str(answer.get(p["id"], "unsure")).lower()
        groups[g if g in groups else "unsure"][p["id"]] = p["title"]
    sources[point.code] = {"_made_by": f"{args.writer_model} on {datetime.now():%Y-%m-%d}",
                           "_words": point.markers, **groups}
    SOURCES_PATH.write_text(json.dumps(sources, ensure_ascii=False, indent=2), encoding="utf-8")
    for g in ("is", "not", "unsure", "unrelated"):
        print(f"\n{g}:")
        for i, t in groups[g].items():
            print(f"  {i}  {t}")
    if not groups["is"]:
        print("\n[warning] no page teaches this point: the rule would only have the list's own examples to go on.")
    for p in shown:
        if p["id"] in groups["is"] and p.get("hsk_2021") and point.level not in p["hsk_2021"]:
            print(f"\n[note] {p['id']} is tagged HSK {p['hsk_2021']} on the wiki, the point is HSK {point.level} "
                  "(often fine: one point can cover a later page's word, like 1-10 and 一起).")
    print(f"\nSaved to {SOURCES_PATH}. No need to edit it unless validate shows a problem. Next: write --code {point.code}")


# --------------------------------- CONTAINS CHECK (cached) ---------------------------------

def contains_point(client, point: Point, items: list[tuple[str, str]], cache: dict) -> dict:
    """{hanzi: True/False}: does the sentence contain the point at all (even
    with something harder in it too)? items: [(hanzi, tagged)]. Haiku,
    CHECK_BATCH per call, cached. A failed call or missing answer -> False
    (the sentence stays a counter-example: the safe side)."""
    key = lambda h: json.dumps(["contains", gr.CONTAINS_VERSION, point.code, h], ensure_ascii=False)
    todo = [(h, t) for h, t in dict(items).items() if key(h) not in cache]
    context = point.context(full=False)

    def one(chunk):
        listing = [{"n": k, "hanzi": h, "tagged": t} for k, (h, t) in enumerate(chunk, 1)]
        try:
            answers = gr.extract_json_array(call(client, JUDGE_MODEL, gr.contains_prompt(point.code, context, listing),
                                                 2000 + 40 * len(chunk)))
            by_n = {int(a["n"]): a for a in answers if isinstance(a, dict) and "n" in a}
        except Exception:
            return
        for k, (h, _) in enumerate(chunk, 1):
            a = by_n.get(k)
            if a and isinstance(a.get("contains"), bool):
                with _cache_lock:
                    cache[key(h)] = a["contains"]

    if todo:
        chunks = [todo[i:i + CHECK_BATCH] for i in range(0, len(todo), CHECK_BATCH)]
        print(f"  Checking {len(todo)} sentence(s) for {point.code} ({len(chunks)} call(s))...", flush=True)
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            list(pool.map(one, chunks))
        save_json(CACHE_PATH, cache)
    return {h: bool(cache.get(key(h), False)) for h, _ in items}


def uses_beyond(client, lower: Point, higher: Point, items: list[tuple[str, str]], cache: dict) -> dict:
    """{hanzi: True/False} for example sentences of the LOWER point that the
    HIGHER point's rule flags: does the sentence use the higher point beyond
    what the lower point already teaches? (The grammar lists overlap: 1-11
    lists 在 too, but 他在看书 is just 1-42.) Unsure, a failed call or a
    missing answer -> True: the guard stays (the safe side)."""
    key = lambda h: json.dumps(["beyond", gr.CONTAINS_VERSION, lower.code, higher.code, h], ensure_ascii=False)
    todo = [(h, t) for h, t in dict(items).items() if key(h) not in cache]

    def one(chunk):
        listing = [{"n": k, "hanzi": h, "tagged": t} for k, (h, t) in enumerate(chunk, 1)]
        try:
            answers = gr.extract_json_array(call(client, JUDGE_MODEL,
                                                 gr.beyond_prompt(lower.short_def(), higher.short_def(), listing),
                                                 2000 + 40 * len(chunk)))
            by_n = {int(a["n"]): a for a in answers if isinstance(a, dict) and "n" in a}
        except Exception:
            return
        for k, (h, _) in enumerate(chunk, 1):
            a = by_n.get(k)
            if a and isinstance(a.get("beyond"), bool):
                with _cache_lock:
                    cache[key(h)] = a["beyond"]

    if todo:
        chunks = [todo[i:i + CHECK_BATCH] for i in range(0, len(todo), CHECK_BATCH)]
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            list(pool.map(one, chunks))
        save_json(CACHE_PATH, cache)
    return {h: cache.get(key(h), True) for h, _ in items}


# --------------------------------- WRITE ---------------------------------

def ask_writer(client, point: Point, prompt: str, args, what: str, small_prompt: str | None = None) -> str:
    """Asks for a rule section; retries once with the problem explained. An
    EMPTY answer (very long prompts, e.g. for 了) is retried with
    small_prompt, the same request with fewer example sentences."""
    error, section = None, None
    for attempt in range(2):
        base = small_prompt if (error == "the answer was empty" and small_prompt) else prompt
        p = base if error is None or error == "the answer was empty" else (
            base + f"\n\nYour previous answer could not be used: {error}\nReply again with the corrected section only.")
        print(f"  Asking {args.writer_model} to {what} the rule (usually under a minute)...", flush=True)
        response, answer = create(client, args.writer_model, p, 4000)
        raw = OUT_DIR / f"writer_{point.code}_{datetime.now():%Y%m%d_%H%M%S}.txt"
        raw.write_text(f"<!-- model: {args.writer_model}; stop_reason: {getattr(response, 'stop_reason', '?')}; "
                       f"prompt: {len(p)} characters -->\n{answer}", encoding="utf-8")
        if not answer.strip():
            error = "the answer was empty"
            print(f"  [retry] the answer was empty (stop reason: {getattr(response, 'stop_reason', '?')})"
                  + ("; retrying with fewer example sentences" if small_prompt else ""))
            continue
        try:
            section = gr.normalize_section(gr.extract_section(point.code, answer))
            gr.parse_rule_block(point.code, section)
            stamp = f"<!-- written by {args.writer_model} on {datetime.now():%Y-%m-%d}; edit freely -->"
            head, _, rest = section.partition("\n")
            rest = "\n".join(l for l in rest.splitlines() if not l.strip().startswith("<!-- written by"))
            return f"{head}\n{stamp}\n{rest}\n"
        except gr.RuleError as e:
            error = str(e)
            print(f"  [retry] the rule couldn't be read: {error} (the AI's full answer: {raw})")
    raise SystemExit(f"The writer's rule couldn't be read twice: {error}\nLast answer:\n{section}")


def labeled(point: Point, tagger: Tagger):
    """{hanzi: tag result} for the examples and the counter-examples (tagging
    failures dropped, with a note)."""
    tags = tagger.tag_all(list(point.positives) + list(point.negatives), "labeled example(s)")
    bad = [h for h, r in tags.items() if "error" in r]
    if bad:
        print(f"  [note] {len(bad)} labeled sentence(s) couldn't be tagged and are left out, e.g. {bad[:3]}")
    pos = {h: tags[h] for h in point.positives if "error" not in tags[h]}
    neg = {h: tags[h] for h in point.negatives if "error" not in tags[h]}
    return pos, neg


def cmd_write(db, point: Point, args):
    _, sections, _ = gr.load_rules(RULES_PATH)
    if point.code in sections and not args.redo:
        raise SystemExit(f"{point.code} already has a rule in {RULES_PATH}. Edit it, or pass --redo.")
    pos, neg = labeled(point, Tagger(db, args.retag))
    rnd = random.Random(0)

    def sample(d, n):
        items = [(h, gr.render(as_clauses(r))) for h, r in d.items()]
        rnd.shuffle(items)
        return items[:n]
    unl = [(s.hanzi, gr.render(clauses_of(s))) for s in pipeline_sentences(db, point)]
    rnd.shuffle(unl)
    pos_s, neg_s = sample(pos, WRITER_EXAMPLES), sample(neg, WRITER_EXAMPLES)
    prompt = gr.writer_prompt(point.code, point.context(), pos_s, neg_s, unl[:WRITER_UNLABELED])
    small = gr.writer_prompt(point.code, point.context(full=False), pos_s[:15], neg_s[:15], unl[:8])
    section = ask_writer(get_client(), point, prompt, args, "write", small_prompt=small)
    gr.save_section(RULES_PATH, point.code, section)
    print(f"\n{section}\nWritten to {RULES_PATH}. Next: validate --code {point.code}")


# --------------------------------- VALIDATE ---------------------------------

def labeled_test(rule, pos, neg):
    missed = [(h, gr.render(as_clauses(r))) for h, r in pos.items() if not rule.found(as_clauses(r))]
    wrong = [(h, gr.render(as_clauses(r)), rule.explain(as_clauses(r))[1]) for h, r in neg.items()
             if rule.found(as_clauses(r))]
    return missed, wrong


def print_labeled(point, pos, neg, missed, wrong):
    print(f"\n=== A. {point.code}: rule on labeled examples (no AI) ===")
    print(f"  examples of {point.code} matched:    {len(pos) - len(missed)}/{len(pos)}")
    print(f"  counter-examples wrongly matched: {len(wrong)}/{len(neg)}   <- should be 0")
    if wrong:
        print(f"\n--- counter-examples the rule WRONGLY matches ({len(wrong)}) ---")
        for h, _, m in wrong:
            print(f"  {h}  -- {point.negatives[h]}  [matched: {' ; '.join(m)}]")
    if missed:
        print(f"\n--- examples of {point.code} the rule misses ({len(missed)}) ---")
        for h, _ in missed:
            print(f"  {h}  -- {point.positives[h]}")


def compare(rule, rows, answers):
    out = {"both yes": [], "both no": [], "rule only": [], "check only": []}
    for s_hanzi, clauses in rows:
        found, m, u = rule.explain(clauses)
        a = answers[s_hanzi][0]
        key = ("both yes" if a["uses_point"] else "rule only") if found else \
              ("check only" if a["uses_point"] else "both no")
        out[key].append((s_hanzi, gr.render(clauses), a.get("reason", ""), m, u))
    return out


def print_comparison(point, result):
    total = sum(len(v) for v in result.values())
    print(f"\n=== B. {point.code}: rule vs AI check on {total} course sentence(s) ===")
    labels = {"both yes": "rule YES, check YES", "both no": "rule no,  check no",
              "rule only": "rule YES, check no   <- possible WRONG MATCHES",
              "check only": "rule no,  check YES  <- possible misses"}
    for k, lab in labels.items():
        print(f"  {len(result[k]):>5}  {lab}")
    for k in ("rule only", "check only"):
        if result[k]:
            print(f"\n--- {labels[k].split('<- ')[1]} ({len(result[k])}) ---")
            for h, _, why, m, u in result[k]:
                fired = f"  [matched: {' ; '.join(m)}]" if m else (f"  [unless: {' ; '.join(u)}]" if u else "")
                print(f"  {h}  -- check: {why}{fired}")


def cmd_validate(db, point: Point, args):
    rules, sections, errors = gr.load_rules(RULES_PATH)
    if point.code in errors:
        raise SystemExit(f"The rule in {RULES_PATH} can't be read: {errors[point.code]}")
    if point.code not in rules:
        raise SystemExit(f"No rule for {point.code} yet: run write --code {point.code} first.")
    rule = rules[point.code]
    pos, neg = labeled(point, Tagger(db, args.retag))
    missed, wrong = labeled_test(rule, pos, neg)
    print_labeled(point, pos, neg, missed, wrong)

    result, client = None, None
    if args.check:
        sentences = pipeline_sentences(db, point)[:args.limit] if args.limit else pipeline_sentences(db, point)
        rows = [(s.hanzi, clauses_of(s)) for s in sentences]
        client, cache = get_client(), load_json(CACHE_PATH, {})
        answers = run_checks(client, point, [{"hanzi": h, "tagged": gr.render(c), "english": None}
                                             for h, c in rows], 1, cache)
        result = compare(rule, rows, answers)
        print_comparison(point, result)
        report = OUT_DIR / f"validate_{point.code}_{datetime.now():%Y%m%d_%H%M%S}.csv"
        with open(report, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["sentence", "outcome", "rule_matched_lines", "rule_unless_lines", "check_reason", "tagged"])
            for k, items in result.items():
                for h, tagged, why, m, u in items:
                    w.writerow([h, k, " ; ".join(m), " ; ".join(u), why, tagged])
        print(f"\nEvery course sentence: {report}")

    if not args.revise:
        return
    chk_wrong = [(h, t, why) for h, t, why, _, _ in (result or {}).get("rule only", [])][:30]
    chk_missed = [(h, t, why) for h, t, why, _, _ in (result or {}).get("check only", [])][:30]
    if not (missed or wrong or chk_wrong or chk_missed):
        print("Nothing to revise.")
        return
    print(f"\nRevising: {len(wrong)} wrong + {len(missed)} missed labeled example(s), "
          f"{len(chk_wrong) + len(chk_missed)} checker disagreement(s)...")
    prompt = gr.revise_prompt(point.code, point.context(), sections[point.code], missed[:40],
                              [(h, t) for h, t, _ in wrong][:40], chk_wrong, chk_missed)
    new = ask_writer(client or get_client(), point, prompt, args, "revise")
    shutil.copy(RULES_PATH, RULES_PATH.with_name(RULES_PATH.name + ".bak"))
    gr.save_section(RULES_PATH, point.code, new)
    print(f"\n{new}\nSaved (old file: {RULES_PATH.name}.bak). Re-testing:")
    new_rule = gr.parse_rule_block(point.code, new)
    print_labeled(point, pos, neg, *labeled_test(new_rule, pos, neg))
    if result is not None:
        print_comparison(point, compare(new_rule, rows, answers))


# --------------------------------- TATOEBA ---------------------------------

def read_tatoeba(path: Path) -> dict:
    """{id: {"original", "english": [translations]}} from the filtered file
    (header row; one row per sentence + translation)."""
    out = {}
    with open(path, encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f, delimiter="\t", quoting=csv.QUOTE_NONE):
            tid, text, eng = (row.get("id") or "").strip(), (row.get("text") or "").strip(), (row.get("eng_text") or "").strip()
            if not tid or not text:
                continue
            item = out.setdefault(tid, {"original": text, "english": []})
            if eng and eng not in item["english"]:
                item["english"].append(eng)
    return out


_TATOEBA = {}


def cmd_tatoeba(db, point: Point, args):
    """Fills a point from Tatoeba -- or, with args.ai_pairs, puts AI-written
    sentences through exactly the same steps (stricter on vocabulary: no
    character outside the list, and no second opinion on rejections)."""
    ai_pairs = getattr(args, "ai_pairs", None)
    max_unknown = 0 if ai_pairs is not None else MAX_UNKNOWN_CHARS
    try:
        from opencc import OpenCC
    except ImportError:
        if ai_pairs is None:
            raise SystemExit("pip install opencc-python-reimplemented  (Traditional -> Simplified)")
    from app.textbook.models import Sentence, Vocab
    from data_pipelines.textbook.scripts import detect_grammar as dg
    from data_pipelines.textbook.scripts import review_sentences as rs

    rules, _, errors = gr.load_rules(RULES_PATH)
    if point.code not in rules:
        raise SystemExit(errors.get(point.code) or f"No rule for {point.code} yet: run write first.")
    level = args.level or point.first_level
    if level < point.first_level:
        print(f"[note] --level {level} is below HSK {point.first_level}, the first level this point's words allow: "
              f"no sentence can be HSK {level}. Using HSK {point.first_level}.")
        level = point.first_level
    print(f"Filling {point.code} at HSK {level}.")
    rule = rules[point.code]
    # rules for HARDER points: a sentence showing one of them is too hard here
    from app.textbook.models import GrammarTip
    level_of = dict(db.query(GrammarTip.grammar_code, GrammarTip.hsk_level).all())
    batch_state = load_json(BATCH_STATE_PATH, {})
    failed = {c for c, st in batch_state.items() if isinstance(st, dict) and st.get("rule") in ("failed", "error")}
    not_here = {c for c, st in batch_state.items()       # guards that wrongly flag this point's own examples
                if isinstance(st, dict) and point.code in (st.get("not_for") or [])}
    harder = {c: r for c, r in rules.items()
              if c != point.code and (level_of.get(c) or 0) > level and c not in failed | not_here}
    print(f"Harder-grammar rules checked (points above HSK {level} with a rule): "
          f"{', '.join(sorted(harder)) or 'none yet'}")
    if ai_pairs is not None:
        print(f"AI-written sentences to check: {len(ai_pairs)}\n")
        pairs = {tid: dict(p, english=list(p["english"])) for tid, p in ai_pairs.items()}
    else:
        tsv = Path(args.tsv) if args.tsv else DEFAULT_TSV
        print(f"Tatoeba file: {tsv}\n")
        if str(tsv) not in _TATOEBA:
            cc = OpenCC("t2s")
            loaded = read_tatoeba(tsv)
            for p in loaded.values():
                p["hanzi"] = cc.convert(p["original"])
            _TATOEBA[str(tsv)] = loaded
        pairs = {tid: dict(p, english=list(p["english"])) for tid, p in _TATOEBA[str(tsv)].items()}
    funnel, outcome, dropped = Counter(), {}, defaultdict(list)

    def drop(tid, step, reason):
        outcome[tid] = (step, reason)
        dropped[step].append((pairs[tid]["hanzi"], reason))

    in_db = {h for (h,) in db.query(Sentence.hanzi).all()} | set(getattr(args, "exclude", None) or ())
    from data_pipelines.textbook.scripts import hsk_vocab_source as hvs
    from data_pipelines.textbook.scripts import tag_sentences as ts
    dictionary = full_dictionary(hvs.load_known_words(str(ts.VOCAB_PATH)))
    listed = {h for (h,) in db.query(Vocab.hanzi).filter(Vocab.hsk_level.isnot(None)).all()}
    known_chars = {ch for (h,) in db.query(Vocab.hanzi).filter(Vocab.hsk_level.isnot(None),
                                                                 Vocab.hsk_level <= level).all() for ch in h}
    first_of, traditional, candidates = {}, 0, []
    for tid, p in pairs.items():
        traditional += p["hanzi"] != p["original"]
    for tid, p in pairs.items():
        if not p["english"]:
            outcome[tid] = ("1", "no English translation")
            continue
        funnel["1. have an English translation"] += 1
        if not any(m in p["hanzi"] for m in point.markers):
            outcome[tid] = ("1", "no marker word")
            continue
        funnel["2. contain the point's word(s)"] += 1
        if p["hanzi"] in in_db:
            drop(tid, "3", "already in the database" if ai_pairs is None else
                 "already in the course or chosen from Tatoeba")
            continue
        if p["hanzi"] in first_of:
            keep = pairs[first_of[p["hanzi"]]]
            keep["english"] += [e for e in p["english"] if e not in keep["english"]]
            drop(tid, "3", f"same text as {first_of[p['hanzi']]} (translations pooled)")
            continue
        first_of[p["hanzi"]] = tid
        funnel["3. new (not in DB, not a duplicate)"] += 1
        unknown = {ch for ch in _CJK_RE.findall(p["hanzi"]) if ch not in known_chars}
        if len(unknown) > max_unknown:
            drop(tid, "4", f"{len(unknown)} characters no HSK {level} word uses: {''.join(sorted(unknown))}")
            continue
        funnel[f"4. at most {max_unknown} characters outside HSK {level} words"] += 1
        candidates.append(tid)
    if args.limit:
        candidates = candidates[:args.limit]

    # ---- 5-6: tag, level, rule ----
    tagger = Tagger(db, args.retag)
    tags = tagger.tag_all([pairs[t]["hanzi"] for t in candidates],
                          "Tatoeba candidate(s)" if ai_pairs is None else "AI-written sentence(s)")
    passed_rule = []
    for tid in candidates:
        p = pairs[tid]
        res = tags[p["hanzi"]]
        if "error" in res:
            drop(tid, "5", f"error while tagging: {res['error']}")
            continue
        if res["level"] != level:
            causes = blockers(res, level) + ([f"grammar {' '.join(res['bump'])}"] if res["bump"] else [])
            drop(tid, "5", f"level {res['level']}: {', '.join(causes) or 'no list words'}")
            continue
        funnel[f"5. really HSK {level}"] += 1
        clauses = as_clauses(res)
        too_hard = [c for c, r in harder.items() if r.found(clauses)]
        if too_hard:
            drop(tid, "5b", "harder grammar: " + ", ".join(f"{c} (HSK {level_of[c]})" for c in too_hard))
            continue
        funnel[f"5b. no harder grammar point (of the {len(harder)} with a rule)"] += 1
        found, m, u = rule.explain(clauses)
        if not found:
            drop(tid, "6", f"rule: {'unless ' + ' ; '.join(u) if u else 'no match: line matched'}")
            continue
        funnel[f"6. the rule finds {point.code}"] += 1
        passed_rule.append({"tid": tid, "hanzi": p["hanzi"], "tagged": gr.render(clauses),
                            "english": list(p["english"]), "words": res["words"], "matched": m,
                            "hidden": hidden_words(res["words"], dictionary, listed, point.markers)})
    db.rollback()

    # ---- 6b: hidden words, decided once per word (hidden_words.json) ----
    verdicts_hw = load_json(HIDDEN_PATH, {})

    def needs_verdict(w):
        v = verdicts_hw.get(w)
        # "hidden" verdicts from before HIDDEN_VERSION 2 were judged on one dictionary meaning
        # (不想 "unexpectedly"): asked again with all of them. Hand-set ones ("by": "hand") are kept.
        return v is None or (isinstance(v, dict) and v.get("verdict") == "hidden"
                             and v.get("v", 1) < HIDDEN_VERSION and v.get("by") != "hand")
    todo = {w: (parts, g) for j in passed_rule for w, parts, g in j["hidden"] if needs_verdict(w)}
    if todo:
        judge_hidden_words(db, args.writer_model, todo, verdicts_hw)
    kept = []
    for j in passed_rule:
        bad = [w for w, _, _ in j["hidden"] if verdicts_hw.get(w, {}).get("verdict") == "hidden"]
        if bad:
            drop(j["tid"], "6b", "hidden word a learner can't work out: "
                 + ", ".join(f"{w} ({verdicts_hw[w].get('gloss', '')})" for w in bad))
            continue
        funnel["6b. no hidden word a learner can't work out"] += 1
        kept.append(j)
    passed_rule = kept

    # ---- how many does the point still need? ----
    have = [s.hanzi for s in pipeline_sentences(db, point)
            if s.hsk_level == level and rule.found(clauses_of(s))]
    need = max(0, args.target - len(have)) if args.target else len(passed_rule)
    if getattr(args, "need", None) is not None:          # the AI fill: what Tatoeba left short
        need = args.need
    print(f"\nCourse sentences at HSK {level} the rule already finds {point.code} in: {len(have)}"
          + (f"  -> Tatoeba needs to add {need} (target {args.target})" if args.target else ""))

    # ---- 7-8: checks + review, shortest sentences first, in rounds, until enough ----
    client, cache = get_client(), load_json(CACHE_PATH, {})
    scope = rs.grammar_scope(db, level)
    survivors, not_checked = [], 0

    hard_easy = harder_points_with_easy_words(db, level)
    print(f"Harder grammar points made only of {'HSK 1' if level == 1 else f'HSK 1-{level}'} words "
          f"(the review is warned about them): {len(hard_easy)}")
    for c, lv, lab in hard_easy[:12]:
        print(f"    {c} (HSK {lv}) {lab}")
    if len(hard_easy) > 12:
        print(f"    ... and {len(hard_easy) - 12} more")
    known = "HSK 1" if level == 1 else f"HSK 1-{level}"
    review_head = (
        "You are checking example sentences for a Mandarin course for beginners. Every sentence below is "
        f"taught at HSK {level} (2025 syllabus) as an example of grammar point {point.code}: {point.label}. That "
        f"point is taught at this level, so never count it -- or its words ({'、'.join(point.markers)}) or its "
        "pattern -- as too hard.\n\n"
        "VOCABULARY IS ALREADY CHECKED: every word of each sentence is in the course's word list for this level, "
        "or is a name. Never reject a sentence because of vocabulary -- you do not have the list.\n\n"
        f"Grammar points learners know ({known}):\n{scope}\n\n"
        + ("THESE GRAMMAR POINTS ARE ABOVE THIS LEVEL even though their words are easy. A sentence that uses "
           "one of them IS TOO HARD:\n" + "\n".join(f"  {c} (HSK {lv}) {lab}" for c, lv, lab in hard_easy) + "\n\n"
           if hard_easy else "")
        + "Mark a sentence TOO HARD only if a learner at this level clearly could NOT work it out:\n"
        "1. it relies on a construction well beyond this level (not just a word you find advanced);\n"
        "2. a word is used in a clearly different meaning from its everyday one;\n"
        "3. it is an idiom whose meaning can't be guessed from its words (everyday set phrases like 不客气, "
        "没关系, 对不起 are fine -- they are taught as words).\n"
        + (rs.HSK1_EXAMPLES + "\n" if level == 1 else "") + rs.FINE_EXAMPLES + "\n"
        "If you are unsure, it is FINE. Judge each sentence on its own.\n\nSENTENCES:\n")

    def review_key(j, n):
        if n == "appeal":                       # the second opinion (JUDGE_MODEL) on a rejected sentence
            return json.dumps(["review-appeal1", JUDGE_MODEL, point.code, level, j["hanzi"], j["chosen"]],
                              ensure_ascii=False)
        return json.dumps(["review6", dg.REVIEW_PROMPT_VERSION, point.code, level, j["hanzi"], j["chosen"], n],
                          ensure_ascii=False)

    def review_chunk(args_):
        """One call reviews a whole round of sentences (the long grammar list is sent once)."""
        n, chunk = args_
        model = JUDGE_MODEL if n == "appeal" else rs.HAIKU_MODEL
        listing = "\n".join(f"[{k}] {j['hanzi']}\n    English: {j['chosen']}\n    words: {' / '.join(j['words'])}"
                            for k, j in enumerate(chunk, 1))
        prompt = (review_head + listing + '\n\nRespond with ONLY a JSON array, one object per sentence: '
                  '[{"n": <sentence number>, "ok": true or false, "problems": ["<short reason>", ...]}, ...]')
        try:
            answers = gr.extract_json_array(call(client, model, prompt, 200 + 120 * len(chunk)))
            by_n = {int(a["n"]): a for a in answers if isinstance(a, dict) and "n" in a}
        except Exception:
            return                                   # not cached: counts as too hard this run
        for k, j in enumerate(chunk, 1):
            a = by_n.get(k)
            if a and isinstance(a.get("ok"), bool):
                v = {"ok": a["ok"], "problems": [str(x) for x in (a.get("problems") or [])] if not a["ok"] else []}
                with _cache_lock:
                    cache[review_key(j, n)] = v

    def review_all(items):
        """Two independent reviews of every item (different order each time);
        too hard if either says so, or if an answer is missing."""
        jobs = []
        for n in range(2):
            todo = [j for j in items if review_key(j, n) not in cache]
            random.Random(n).shuffle(todo)
            jobs += [(n, todo[i:i + CHECK_BATCH]) for i in range(0, len(todo), CHECK_BATCH)]
        if jobs:
            with ThreadPoolExecutor(max_workers=WORKERS) as pool:
                list(pool.map(review_chunk, jobs))
        out = []
        for j in items:
            vs = [cache.get(review_key(j, n), {"ok": False, "problems": ["no answer from the review"]})
                  for n in range(2)]
            bad = [v for v in vs if not v.get("ok")]
            out.append({"ok": True} if not bad else
                       {"ok": False, "problems": [f"({len(bad)}/2)"] + (bad[0].get("problems") or [])})
        return out

    queue = sorted(passed_rule, key=lambda j: len(j["hanzi"]))
    rejected7, rejected8 = [], []               # Haiku's rejections: a second opinion if the point is short
    for start in range(0, len(queue), CHECK_BATCH):
        if len(survivors) >= need:
            not_checked = len(queue) - start
            for j in queue[start:]:
                outcome[j["tid"]] = ("-", "not checked: target reached")
            break
        batch = queue[start:start + CHECK_BATCH]
        answers = run_checks(client, point, batch, 2, cache)
        passed_check = []
        for j in batch:
            a = answers[j["hanzi"]]
            nos = [x.get("reason", "") for x in a if not x["uses_point"]]
            if nos:
                drop(j["tid"], "7", f"check said no ({len(nos)}/2): {nos[0]}")
                rejected7.append(j)
            elif a[0].get("english") is None:
                drop(j["tid"], "7", f"no accurate English among: {' | '.join(j['english'])}")
                rejected7.append(j)
            else:
                j["chosen"] = j["english"][a[0]["english"]]
                passed_check.append(j)
                funnel[f"7. both checks say {point.code}, English chosen"] += 1
        verdicts = review_all(passed_check)
        for j, v in zip(passed_check, verdicts):
            if v.get("ok"):
                funnel["8. both difficulty reviews pass it"] += 1
                survivors.append(j)
                outcome[j["tid"]] = ("8", "passed")
            else:
                drop(j["tid"], "8", f"difficulty review: {'; '.join(v.get('problems') or [])}")
                rejected8.append(j)

    # ---- 7-8 second opinion: only for a point still short of its target ----
    # Haiku makes clear mistakes (所以 called "HSK 3+" in the point that teaches 所以). JUDGE_MODEL
    # looks again at what Haiku rejected, and its answer is final. Sentences Haiku passed don't change.
    if len(survivors) < need and (rejected7 or rejected8) and ai_pairs is None:
        def undrop(j, step, note):
            dropped[step] = [x for x in dropped[step] if x[0] != j["hanzi"]]
            outcome[j["tid"]] = (step, note)

        print(f"  Short of the target: {JUDGE_MODEL} gives a second opinion on {len(rejected7)} check and "
              f"{len(rejected8)} review rejection(s)...", flush=True)
        rescued = []
        if rejected7:
            answers = run_checks(client, point, rejected7, 1, cache, model=JUDGE_MODEL)
            to_review = []
            for j in rejected7:
                a = answers[j["hanzi"]][0]
                if a["uses_point"] and a.get("english") is not None:
                    j["chosen"] = j["english"][a["english"]]
                    undrop(j, "7", "check: passed on second opinion")
                    funnel["7b. second opinion: it is the point (check)"] += 1
                    to_review.append(j)
            for j, v in zip(to_review, review_all(to_review)):
                if v.get("ok"):
                    rescued.append(j)
                else:
                    drop(j["tid"], "8", f"difficulty review: {'; '.join(v.get('problems') or [])}")
                    rejected8.append(j)
        todo = [j for j in rejected8 if review_key(j, "appeal") not in cache]
        if todo:
            with ThreadPoolExecutor(max_workers=WORKERS) as pool:
                list(pool.map(review_chunk, [("appeal", todo[i:i + CHECK_BATCH])
                                             for i in range(0, len(todo), CHECK_BATCH)]))
        for j in rejected8:
            v = cache.get(review_key(j, "appeal"))
            if v and v.get("ok"):
                undrop(j, "8", "review: passed on second opinion")
                funnel["8b. second opinion: not too hard (review)"] += 1
                rescued.append(j)
            elif v:
                dropped["8"] = [(h, r + "  [second opinion agrees]" if h == j["hanzi"] else r)
                                for h, r in dropped["8"]]
        rescued.sort(key=lambda j: len(j["hanzi"]))
        for j in rescued:
            if len(survivors) >= need:
                outcome[j["tid"]] = ("-", "rescued, but the target was already reached")
                continue
            survivors.append(j)
            outcome[j["tid"]] = ("8", "passed (second opinion)")
    save_json(CACHE_PATH, cache)

    # ---- report ----
    chosen = {j["tid"]: j for j in passed_rule}
    report = OUT_DIR / (f"{'tatoeba' if ai_pairs is None else 'ai'}_{point.code}_level{level}_"
                        f"{datetime.now():%Y%m%d_%H%M%S}.csv")
    with open(report, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["tatoeba_id", "hanzi", "original", "english_chosen", "english_options",
                    "stopped_at_step", "reason", "rule_matched_lines", "hidden_words"])
        for tid, (step, reason) in outcome.items():
            if reason in ("no marker word", "no English translation"):
                continue
            p, j = pairs[tid], chosen.get(tid, {})
            w.writerow([tid, p["hanzi"], p["original"], j.get("chosen", ""), " | ".join(p["english"]),
                        step, reason, " ; ".join(j.get("matched", [])),
                        " ; ".join(f"{w} ({g})" for w, _, g in j.get("hidden", []))])

    print(f"\n=== {point.code} at HSK {level}: funnel ===")
    print(f"  {len(pairs):>7}  {'Tatoeba sentences in the file' if ai_pairs is None else 'AI-written sentences'}")
    for k in sorted(funnel):
        print(f"  {funnel[k]:>7}  {k}")
    if traditional:
        print(f"  ({traditional} were in Traditional characters and converted)")
    if not_checked:
        print(f"  ({not_checked} sentence(s) passed the rule but weren't checked: target reached)")
    print(f"\n=== Survivors ({len(survivors)}) ===")
    for j in survivors:
        hid = f"  hidden: {', '.join(w for w, _, _ in j['hidden'])}" if j.get("hidden") else ""
        print(f"  {j['hanzi']}  ({j['chosen']})  [tatoeba {j['tid']}]{hid}")
    for step in sorted(dropped):
        items = dropped[step]
        n = len(items) if step in ("6", "7", "8") else min(len(items), SAMPLES_PER_STEP)
        print(f"\n--- dropped at step {step} ({len(items)}){'' if n == len(items) else f', first {n}'} ---")
        for hanzi, reason in items[:n]:
            print(f"  {hanzi}  -- {reason}")
    print(f"\nEvery sentence and why: {report}")
    return {"level": level, "have": len(have), "need": need, "added": len(survivors),
            "survivors": [{"tatoeba_id": j["tid"], "hanzi": j["hanzi"], "english": j["chosen"]} for j in survivors],
            "candidates_after_rule": len(passed_rule), "funnel": dict(funnel),
            "outcome": {tid: list(v) for tid, v in outcome.items()}}


# --------------------------------- MAIN ---------------------------------

def main():
    global CHECK_MODEL
    parser = argparse.ArgumentParser(description="Trial: grammar rule from references + Tatoeba, one point.")
    parser.add_argument("step", choices=["sources", "context", "write", "validate", "tatoeba"],
                        help="sources: AI proposes the point's AllSet Learning pages. "
                             "context: just print what the AI is told about the point.")
    parser.add_argument("--code", default="1-10", help="Grammar point (default 1-10).")
    parser.add_argument("--contains", nargs="+", default=None, help="Marker words instead of GRAMMAR_MARKERS.")
    parser.add_argument("--writer-model", default=WRITER_MODEL)
    parser.add_argument("--check-model", default=CHECK_MODEL, help=f"Model for the checks (default {CHECK_MODEL}).")
    parser.add_argument("--redo", action="store_true", help="sources/write: replace what's there.")
    parser.add_argument("--revise", action="store_true", help="validate: one revision from the failures.")
    parser.add_argument("--check", action="store_true",
                        help="validate: also compare with an AI check on the course sentences (costs a little).")
    parser.add_argument("--target", type=int, default=DEFAULT_TARGET,
                        help=f"tatoeba: stop once the point has this many sentences at the level, counting the "
                             f"course's own (default {DEFAULT_TARGET}; 0 = check every candidate).")
    parser.add_argument("--retag", action="store_true", help="Ignore the tagging cache.")
    parser.add_argument("--level", type=int, default=None,
                        help="tatoeba: HSK level (default: the first level the point's words allow).")
    parser.add_argument("--tsv", default=None, help=f"tatoeba: file (default {DEFAULT_TSV.name}).")
    parser.add_argument("--limit", type=int, default=None, help="validate/tatoeba: at most N sentences.")
    args = parser.parse_args()

    CHECK_MODEL = args.check_model
    install_credit_guard()
    t0 = time.time()
    real = point_db_at_scratch_copy()
    from app.textbook.db_utils import get_session, init_db
    init_db()
    apply_level_overrides()
    print(f"Working on a copy of {real}\n")
    with get_session() as db:
        point = Point(db, args.code, args.contains, need_sources=args.step not in ("sources", "context"))
        point.show()
        if args.step == "context":
            print(point.context())
        else:
            {"sources": cmd_sources, "write": cmd_write, "validate": cmd_validate,
             "tatoeba": cmd_tatoeba}[args.step](db, point, args)
        db.rollback()
    print(f"\nDone in {time.time() - t0:.0f}s. The real database was not changed.")


if __name__ == "__main__":
    main()
